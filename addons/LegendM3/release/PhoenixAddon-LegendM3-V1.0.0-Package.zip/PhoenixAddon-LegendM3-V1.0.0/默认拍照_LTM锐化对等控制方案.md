# 默认拍照 LTM/锐化置零修改点

状态：仅供后续实现参考；本轮不修改普通拍照代码，也不涉及跨代移植。

## 目标

普通拍照模式后续需要提供独立的 LTM 与 ASF 锐化置零能力。默认关闭时保持当前 AUTH/VIBR
原生行为；开启后只对本请求的指定节点置零，不复用 M3 的 module 256 分支。

## LTM 修改点

- 复用 `native/m3_ltm_runtime.cpp` 已建立的 `IPENode → metadata getter → IPELTM202 →
  LTM202Setting` 逐请求上下文。
- 用输入 metadata 的 `xiaomi.app/module == 163` 守卫普通拍照；module 256 继续只属于 M3。
- 在 `LTM202Setting::CalculateHWSetting` 调用前复制 267-word region，按配置只写控制槽：
  `165 (+0x294)` 为 65 点 scale 总强度，`168 (+0x2a0)` 为 LCE 正负曲线总强度。
- “LTM 置零”写 165=0；“LCE 置零”写 168=0。166/167 是暗端/亮端分量，除非以后
  明确要求，否则保留原值。region 其余字段逐字节不变。
- 排除特殊 LTM 输入分支；缺少 module、请求上下文或有效 region 时直接走原生调用。

已验证 M3 侧 165 置零会使原生处理后的 65 点 scale 全部归零，168 置零会使两组 LCE
输出表归零，恢复原值后输出逐字节恢复。普通模式实施时复用相同验证方法。

## ASF 锐化修改点

- 在普通拍照的 ASF351 `CalculateHWSetting` 前建立独立的 module 163 守卫和复制区。
- 找到 ASF351 中对应正/负锐化增益的两层 64 点曲线后，将这些目标曲线置零；不使用专业
  模式 UI 的 `sharpness` 参数，也不修改软阈值、活动度、RNR、肤色、滤波核和目标侧扩展字段。
- 具体字段偏移、量化和输出表仍需在实施普通模式置零时以当前设备二进制闭环；本轮 M3
  移植研究不会把 M3 donor 参数写入普通拍照。

## 验收

程序化检查 module 163 命中、原生 setting 成功、目标 scale/LCE 或锐化增益表归零、非目标
字段不变、关闭后输出精确恢复；同时确认 module 256 M3 分支不受普通模式开关影响。

依据：`native/m3_ltm_runtime.cpp`、`native/m3_ltm.cpp`、`lce_device_effect.md`、
`evidence/iq_request_20260913T115707678075Z.json`、
`evidence/iq_request_20260913T120358371931Z.json`。
