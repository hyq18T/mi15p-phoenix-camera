#pragma once

// Read-only ABI notes for a future 14U Mivi/PluginWraper adapter.
//
// This file deliberately contains no production adapter and is not included by
// the currently built m3_grain component.  The values below are the minimum
// facts needed to write one without guessing the host's C++ ABI.  Addresses in
// the comments are ELF virtual addresses in the original 14U libraries.

#include <stddef.h>
#include <stdint.h>

namespace m3::mivi14 {

// FilterPlugin::initialize(CreateInfo*, MiaNodeInterface) receives the third
// argument as a pointer to eight 64-bit words on AArch64 (the source-level
// type is a 0x40-byte by-value aggregate).  The original implementation at
// filter.so:0xC08C copies all eight words to this+0x08..0x40.
struct MiaNodeInterface {
    uintptr_t words[8];
};
static_assert(sizeof(MiaNodeInterface) == 0x40);

// MiaNode::isEnable(MiaParams) copies 0x48 bytes before dispatching the
// PluginWraper::isEnabled virtual (libmialgoengine.so:0x5066C).  The first
// qword is used as a metadata handle by the original FilterPlugin, but the
// remaining fields have not been assigned names here.
struct MiaParamsOpaque {
    uint8_t bytes[0x48];
};
static_assert(sizeof(MiaParamsOpaque) == 0x48);

// ImageParams is intentionally opaque: the original object is larger than the
// fields consumed by FilterPlugin::convertImageParams.  These offsets are
// verified in filter.so:0xD4F0 and are sufficient for an adapter view.
struct ImageParamsOffsets {
    static constexpr size_t format = 0x00;
    static constexpr size_t width = 0x04;
    static constexpr size_t height = 0x08;
    static constexpr size_t source_buffer = 0x28; // used by other filter code
    static constexpr size_t stride = 0x1C;
    static constexpr size_t scanline = 0x20;
    static constexpr size_t num_planes = 0x48;
    static constexpr size_t fds = 0x4C;
    static constexpr size_t plane_ptrs = 0x58;
    static constexpr size_t data = 0x70; // independently reported in the M3 ABI report
};

// ProcessRequestInfo's first two members are libc++ std::map objects.  A
// libc++ map object is 0x18 bytes on the 14U build.  The vector element type is
// the opaque ImageParams above; its complete size is deliberately not asserted
// until a matching Android libc++ build is available.
struct ProcessRequestOffsets {
    static constexpr size_t input_buffers = 0x00;
    static constexpr size_t output_buffers = 0x18;
    static constexpr size_t first_known_trailing_field = 0x30;
};

// Offsets are relative to the object's vptr address point (not the beginning
// of the Itanium ZTV object).  The original 14U FilterPlugin and the
// libmialgoengine call sites establish this order; for example, engine
// filter-plugin calls load vptr+0x40 for isEnabled (engine.so:0x46458),
// vptr+0x28 for postProcess (engine.so:0x457E0), and vptr+0x38/0x58 for
// destroy/deleting-destructor (engine.so:0x4575C/0x45770).
struct PluginWraperVtable {
    static constexpr size_t initialize = 0x00;
    static constexpr size_t pre_process = 0x08;
    static constexpr size_t process_request_v1 = 0x10;
    static constexpr size_t process_request_v2 = 0x18;
    static constexpr size_t customize_out_buffer_formats = 0x20;
    static constexpr size_t post_process = 0x28;
    static constexpr size_t flush_request = 0x30;
    static constexpr size_t destroy = 0x38;
    static constexpr size_t is_enabled = 0x40;
    static constexpr size_t base_slot9 = 0x48; // name not proven from exports
    static constexpr size_t complete_destructor = 0x50;
    static constexpr size_t deleting_destructor = 0x58;
    static constexpr size_t convert_image_params = 0x60;
    static constexpr size_t is_pre_processed = 0x68;
    static constexpr size_t support_pre_process = 0x70;
};

// Provider vtable offsets, relative to its vptr, verified from the original
// FilterPlugin provider ZTV at 0x1D090 / vptr 0x1D0A0.  The provider's base
// destructor entries are not included because their complete inheritance layout
// is not needed by the current experiment.
struct ProviderVtable {
    static constexpr size_t get_interface_version = 0x00; // returns int 1
    static constexpr size_t get_provider_type = 0x08;      // std::string
    static constexpr size_t create = 0x10;
    static constexpr size_t get_name = 0x18;               // std::string
};

// Provider globals in libcom.xiaomi.pluginutils.so: interface version and
// lowest version are both 1; the provider type literal is "PluginWraper".
static constexpr uint32_t kPlumaInterfaceVersion = 1;
static constexpr uint32_t kPlumaLowestVersion = 1;

} // namespace m3::mivi14
