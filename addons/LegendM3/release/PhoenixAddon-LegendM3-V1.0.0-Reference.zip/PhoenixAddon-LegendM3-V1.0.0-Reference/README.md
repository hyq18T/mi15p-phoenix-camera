PhoenixAddon-LegendM3 V1.0.0 技术参考。包含完整链路说明、14U 适配边界、EXIF 与 MediaEditor 更新，以及筛选后的结构化证据。
