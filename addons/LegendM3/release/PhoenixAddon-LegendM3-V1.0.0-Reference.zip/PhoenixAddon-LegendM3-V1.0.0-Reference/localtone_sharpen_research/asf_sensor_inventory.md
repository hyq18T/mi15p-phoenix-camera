# ASF353 runtime-route inventory

Static route model superseding the earlier no-scene inventory. Source evidence is `asf_curve_probe_20260913T150523126118Z.json`; only original seven-level vectors are used. Each route replaces ID3/feature0 with 8 and preserves IDs0–2 and IDs4–6, including feature1=80 and scene32. The model prefers an exact/reachable feature0=8 chain, retries feature1=0 when a requested feature1 branch is absent, then retries feature0=0 and keeps the longest V6 prefix. This is a serialized-tree model, not a runtime claim.

| Sensor | observed route groups | selected ASF records (M3 first) |
|---|---|---|
| `ofilm_ovx10500u_wide_ii` | 6 | m1=1,f1=80,s32:M3:5678(m3_prefix_default_feature1,d5); m1=1,f1=0,s32:M3:5678(m3_prefix,d5); m1=4,f1=0,s32:M3:12443(m3_prefix,d4); m1=4,f1=80,s32:M3:12443(m3_prefix,d4); m1=7,f1=80,s32:F0:14487(feature0_default_prefix,d3); m1=7,f1=0,s32:F0:14487(feature0_default_prefix,d3) |
| `semco_ovx10500u_wide_i` | 6 | m1=1,f1=80,s32:M3:5679(m3_prefix_default_feature1,d5); m1=1,f1=0,s32:M3:5679(m3_prefix,d5); m1=4,f1=0,s32:M3:12444(m3_prefix,d4); m1=4,f1=80,s32:M3:12444(m3_prefix,d4); m1=7,f1=80,s32:F0:14488(feature0_default_prefix,d3); m1=7,f1=0,s32:F0:14488(feature0_default_prefix,d3) |
| `ofilm_s5kjn5_ultra_i` | 6 | m1=1,f1=80,s32:M3:508(m3_prefix,d4); m1=1,f1=0,s32:M3:508(m3_prefix,d4); m1=4,f1=0,s32:F0:4670(feature0_default_prefix,d3); m1=4,f1=80,s32:F0:4670(feature0_default_prefix,d3); m1=7,f1=80,s32:F0:2(feature0_default_prefix,d1); m1=7,f1=0,s32:F0:2(feature0_default_prefix,d1) |
| `semco_s5khpe_tele_i` | 6 | m1=1,f1=80,s32:F0:2(feature0_default_prefix,d1); m1=1,f1=0,s32:F0:2(feature0_default_prefix,d1); m1=4,f1=0,s32:M3:7025(m3_prefix,d4); m1=4,f1=80,s32:M3:7025(m3_prefix,d4); m1=7,f1=80,s32:F0:2(feature0_default_prefix,d1); m1=7,f1=0,s32:F0:2(feature0_default_prefix,d1) |

`exact_m3_record_ids` is retained per route in the JSON; the current observed vectors have no seven-level exact feature0=8 record. Records such as wide_ii 5678/semco-wide_i 5679, ultra_i 508, and tele_i 7025 are reachable M3 prefixes for subsets of the routes; scene32 and feature1=80 therefore cannot be filtered out before route matching.
