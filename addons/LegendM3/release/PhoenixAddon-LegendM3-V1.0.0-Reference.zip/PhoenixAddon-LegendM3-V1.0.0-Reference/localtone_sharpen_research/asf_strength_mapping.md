# ASF353 to ASF351 strength mapping

Static-only ordinary-Photo map from the original Calculate consumers; UI
sharpness metadata is excluded. The donor executor is
`libhwliqinterface2.so:0xec7c30`. The target reference Calculate is
`0xec22f0`; its offline build-id differs from the current device.

| ASF353 donor windows | ASF351 target windows | Count / representation | Status |
|---|---|---:|---|
| `0x050..0x14f` + `0x490..0x58f` | `0x350..0x44f` + `0xaa0..0xb9f` | 64 + 64 float32 | verified stage/quantization; likely positive gain L1/L2 |
| `0x150..0x24f` + `0x590..0x68f` | `0x450..0x54f` + `0xba0..0xc9f` | 64 + 64 float32 | verified stage/quantization; likely negative gain L1/L2 |
| `0x250..0x34f` + `0x690..0x78f` | `0x550..0x64f` + `0xca0..0xd9f` | 64 + 64 float32 | verified stage/quantization; likely gain-weight L1/L2 |

Each target pair feeds the corresponding six hardware DMI blocks beginning
`+0x07f,+0x17f,+0x27f,+0x37f,+0x47f,+0x57f`. For the positive and negative
families, the 17U consumer's `0x40ff0000` cap is `255/32`; its endpoint path
uses `round(sample*32)`, then the per-layer float control, and clamps to
`[0,255]`. This matches the reference ASF30 Q5 implementation
(`FloatToQNumber(..., 5) * sharpnessVal`) at the effect boundary. The 14U
target's exact live multiplier still needs current-device Calculate matching;
the old `0xec22f0` helper is an offline reference. The weight pair's Q/inverse
encoding is unresolved for ASF353. Preserve ASF351-only words
`0x13a0..0x13ac` and all non-gain defaults.

**Status:** offsets/counts and consumer saturation: verified; semantic labels
and exact Q interpretation: likely/unresolved.
