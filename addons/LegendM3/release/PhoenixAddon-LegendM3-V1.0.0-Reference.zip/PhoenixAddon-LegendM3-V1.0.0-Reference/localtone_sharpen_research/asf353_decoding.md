# Static ASF353 decoding

`tools/decode_asf353_regions.py` reads the original 17U V6 tuning binary and `evidence/m3_tuning_records.json`. It validates the TOC, follows section-3 symbols and trigger blocks, and resolves each ASF353 304-byte module descriptor. Its final root reference is indirection, not numeric data.

Each region block is `<u32 size><payload>`; ASF353 leaves must be 2820 bytes. Static audit of the exact loader shows serialized array 19 (`0x14` bytes) is copied to a loader-local temporary at `0x9ed02c`, so it must not overwrite numeric offsets `0x948..0x95b`. The 13 following scalar words store at `0x948..0x978`, including `0x968`; `0x97c..0x98f` is zero-initialized. The decoder records the temporary payload and reserved range in its manifest, then emits the `0xAB0` numeric object. No native execution is used.

Next required step: inspect emitted numeric fields and establish their semantics before any 14U mapping. The 17U `libhwliqinterface2.so` `0x1410` value is a hardware-output region; 14U `0x1108` is an interpolation-input region and must not be compared directly. No native code or device execution is used.

The manifest at `dist/asf353_decoded/manifest.json` maps each `record_1799`, `record_1810`, and `record_1821` leaf to its numeric file; arrays at numeric `0x050` and `0x490` are ready for field comparison.
