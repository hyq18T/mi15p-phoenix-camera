# ASF353/ASF351 trigger axes (static)

**Verified from the 14U disassembly:** `ASF351Interpolation::RunInterpolation`
receives `vector<vector<float>>`. The outer stride is 24 bytes, and the loop
groups four inner vectors (`x9 += 0x60`), so inner-vector order is the four
runtime axes. At `0x10ab8d4`, `0x10ab944`, `0x10ab9b0`, and `0x10aba1c` it
loads only `inner.begin()[0]`. The second float in the observed vectors is not
consumed by this routine. Therefore the observer output must **not** be called
`[parameter_id,value]`; no parameter ID is encoded here. The six ASF samples in
`evidence/iq_request_20260913T114234758530Z.json` are:

```json
{"axis0_first":[1000,16],"axis1_first":[2],"axis2_first":[0,5],"axis3_first":[1],
 "axis0_second":[2,6.4],"axis1_second":[4.1322465],
 "axis2_second":[274.56726,274.57468,274.57571,274.57779,274.57935,1],
 "axis3_second":[11.209258]}
```

The first lane is the value used for ASF351 axis lookup; the producer and
meaning of the second lane remain unresolved. The native routine builds
brackets in this ordered axis list. `DoInterpolation` clamps ratio `<=0` to
the lower region and `>=1` to the upper region; otherwise it linearly blends
the complete `0x1108`-byte ASF351 region. This gives the exact interpolation
rule, but not a 14U-to-17U semantic converter.

**17U donor graph:** ASF353 V6 trigger nodes store ordered `(low,high,branch)`
levels, not 14U parameter IDs. Record 1771 is
`[0,0],[1,1],[2,1],[3,8]`, tree `26844`, and is the same tree as LTM1775.
Record 5678 is `[0,0],[1,1],[2,0],[3,8],[4,0]`, tree `7330`; its 57 full
paths match ordinary comparator 585. Do not select a leaf by comparing the
observed pair lanes or by numeric range alone; a converter from current ASF351
first-lane values to the ASF353 graph axes is still **unresolved**.

**`[4,0]` guard/source:** `evidence/stock17_update_custom_feature.c` reads
`com.xiaomi.customization.tuning.feature1` into a zero-initialized local and
overwrites it only when that metadata is present. `stock17_legend_tuning.c`
sets M3 `feature0=8` (`param[2]`) and does not set feature1. Thus 5678's
`[4,0]` is the default ordinary-feature1 guard; it is valid only when upstream
feature1 metadata is absent/zero.
